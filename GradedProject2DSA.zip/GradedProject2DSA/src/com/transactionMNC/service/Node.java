package com.transactionMNC.service;

import java.io.*;

public class Node{

    int val;
    public Node left;
	public Node right;
    
   
    public Node(int item)
    {
        val = item;
        left = right = null;
    }
}